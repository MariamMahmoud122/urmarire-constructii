README

This entry includes:
- index.html
- assets/css/style.css
- assets/js/main.js
- assets/img/logo.png

Theme: cream + green
Colors: #F9F4EC (background), #0E7B6B (accents)

All texts kept from the original brief.
Responsive, accessible, and mobile-optimized.

How to edit:
- Change contact info and colors in index.html and style.css.
- WhatsApp & Phone buttons are dynamic.
- Calculator works with RON/year estimation.

Images are free for commercial use (Pexels & Unsplash).
